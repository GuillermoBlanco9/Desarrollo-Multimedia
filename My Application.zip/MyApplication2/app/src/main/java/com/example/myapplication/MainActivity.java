    package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.*;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Button customButton = findViewById(R.id.button32);
        //TextView textview1 = findViewById(R.id.textView);

        final int[] num1 = {0};
        Random rand = new Random();


/*
        customButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

            }
        });*/
    }

}



